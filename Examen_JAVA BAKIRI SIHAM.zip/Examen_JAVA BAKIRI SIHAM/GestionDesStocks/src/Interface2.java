public interface Interface2 {

    public int getCode();
    public void setCode();
}
