import java.util.Random;

public class Responsable_de_gestion  {

    //Les attributs d'instance
    String nom,prenom,adresse,service,mission,email;
    float salaire;
    int telephone,date_embauche,numero_depot;

    //Le constructeur
    public Responsable_de_gestion(String nom,String prenom,String adresse,String email, int telephone, int date_embauche,int numero_depot, float salaire,String service,String mission){
        this.nom = nom;
        this.prenom = prenom;
        this.adresse = adresse;
        this.email = email;
        this.telephone = telephone;
        this.date_embauche = date_embauche;
        this.numero_depot = numero_depot;
        this.salaire = salaire;
        this.service = service;
        this.mission = mission;
    }

    //Le  deuxieme constructeur
    public Responsable_de_gestion(String nom,String prenom,String email, int date_embauche,int numero_depot, float salaire,String service,String mission){
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.date_embauche = date_embauche;
        this.numero_depot = numero_depot;
        this.salaire = salaire;
        this.service = service;
        this.mission = mission;
    }
    //Le  deuxieme constructeur
    public Responsable_de_gestion(String nom,String prenom,String email,int numero_depot,
                                  float salaire,String service){
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.numero_depot = 4;
        this.salaire = salaire;
        this.service = service;
    }

    // LE constructeur aléatoire:
    public Responsable_de_gestion() {
        Random rand = new Random();

        this.nom = "Valeur aléatoire ";
        this.salaire=rand.nextFloat(30);
        this.prenom = "Valeur aléatoire ";
        this.mission="valeur ";
    }

//get et set :

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getMission() {
        return mission;
    }

    public void setMission(String mission) {
        this.mission = mission;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public float getSalaire() {
        return salaire;
    }

    public void setSalaire(float salaire) {
        this.salaire = salaire;
    }

    public int getTelephone() {
        return telephone;
    }

    public void setTelephone(int telephone) {
        this.telephone = telephone;
    }

    public int getDate_embauche() {
        return date_embauche;
    }

    public void setDate_embauche(int date_embauche) {
        this.date_embauche = date_embauche;
    }

    public int getNumero_depot() {
        return numero_depot;
    }

    public void setNumero_depot(int numero_depot) {
        this.numero_depot = numero_depot;
    }

    //methode d'affichage:
    public void afficherResponsable() {
        System.out.println(" Le information de resposnsable sont: " + this.nom + "," +this.prenom +","+ this.adresse+ "," + this.email +
                "," + this.date_embauche + "," + this.numero_depot + "," + this.service + "," + this.mission + "," + this.salaire + this.telephone);
    }
}

