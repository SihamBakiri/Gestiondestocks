import java.util.Random;

public class Depots implements  InterfaceModel,Interface2 {
    //attribut de classe:
    int Totale_depots= 30;

    //attributs d'instances:
    public int code;
    public String nom,adresse,pays,ville,responsable,produits_stockes;
    public float capacite_maximale, ventes_annuelles;
    public int nombe_chambre_froides;

    //Le premier constructeur
    public Depots(int code,String nom, String adresse,
                  String ville,String pays,String responsable,float capacite_maximale,
                  int nombe_chambre_froides,String produits_stockes, float ventes_annuelles) {

        this.nom = nom;
        this.code = code;
        this.nombe_chambre_froides = nombe_chambre_froides;
        this.adresse = adresse;
        this.ville = ville;
        this.pays = pays;
        this.responsable = responsable;
        this.capacite_maximale = capacite_maximale;
        this.produits_stockes = produits_stockes;
        this.ventes_annuelles = ventes_annuelles;

    }
    // Deuxime constructeur
    public Depots( String ville,String pays,String responsable,float capacite_maximale){
        this.ville = ville;
        this.pays = pays;
        this.responsable = responsable;
        this.capacite_maximale = capacite_maximale;
    }
    //Le troisieme constructeur:

    public Depots(int code,String nom, String adresse,
                  String ville,String pays,float capacite_maximale,
                  int nombe_chambre_froides,String produits_stockes) {

        this.nom = nom;
        this.code = 33456;
        this.nombe_chambre_froides = nombe_chambre_froides;
        this.adresse = adresse;
        this.ville = ville;
        this.pays = "France";
        this.capacite_maximale = capacite_maximale;
        this.produits_stockes = produits_stockes;


    }

    //Le constructeur Aléatoire:
    public Depots() {
        Random rand = new Random();

        this.nom = "Valeur aléatoire ";
        this.nombe_chambre_froides=rand.nextInt(30);
        this.ville = "Valeur aléatoire ";
        this.capacite_maximale = rand.nextFloat(200);
        this.adresse="valeur ";
    }



    //Les methodes:
    //get et set generer par l'interface:
    @Override
    public String getNom() {
        return null;
    }

    @Override
    public int getAdresse() {
        return 0;
    }

    @Override
    public int getEmail(){
        return 0;
    }

    @Override
    public int getVille() {
        return 0;
    }

    @Override
    public int getPays() {
        return 0;
    }

    @Override
    public void setNom(String nom) {

    }

    @Override
    public void setAdresse(String adresse) {

    }

    @Override
    public void setEmail(String email) {

    }

    @Override
    public void setVille(String ville) {

    }

    @Override
    public void setPays(String pays) {

    }


    //get et set sans l'interface:


    public String getResponsable() {
        return responsable;
    }

    public void setResponsable(String responsable) {
        this.responsable = responsable;
    }

    public String getProduits_stockes() {
        return produits_stockes;
    }

    public void setProduits_stockes(String produits_stockes) {
        this.produits_stockes = produits_stockes;
    }

    public float getCapacite_maximale() {
        return capacite_maximale;
    }

    public void setCapacite_maximale(float capacite_maximale) {
        this.capacite_maximale = capacite_maximale;
    }

    public float getVentes_annuelles() {
        return ventes_annuelles;
    }

    public void setVentes_annuelles(float ventes_annuelles) {
        this.ventes_annuelles = ventes_annuelles;
    }

    public int getNombe_chambre_froides() {
        return nombe_chambre_froides;
    }

    public void setNombe_chambre_froides(int nombe_chambre_froides) {
        this.nombe_chambre_froides = nombe_chambre_froides;
    }



    //methode d'affichage:
    public void afficherDepot() {
        System.out.println(" Le depot concernée est le : "
                + this.nom + "," +this.code +","+ this.adresse+ "," + this. ville +
                "," + this.pays + "," + this.responsable
                + "," + this.capacite_maximale + "," + this.nombe_chambre_froides
                + "," + this.produits_stockes + this.ventes_annuelles);
    }

    //Methode implementer par interface2
    @Override
    public int getCode() {
        return 0;
    }

    @Override
    public void setCode() {

    }
}

