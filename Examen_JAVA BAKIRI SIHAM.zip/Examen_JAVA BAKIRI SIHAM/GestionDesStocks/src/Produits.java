import java.util.List;
import java.util.Random;

public class Produits implements Interface2{

    //les attributs d'instances :
    public String nom_produit, fournisseur, type_de_produits, pays_origine;
    public float quantite_stocké, prix_unitaire, poids, quantite;
    public int code_barre, date_expiration;


    //Le Premier constructeur
    public Produits(String nom_produit, float quantite_stocké, float prix_unitaire, int date_expiration, String fournisseur, int code_barre, String pays_origine
            , float quantité_livrée, String type_de_produits, float poids) {

        this.nom_produit = nom_produit;
        this.quantite_stocké = quantite_stocké;
        this.prix_unitaire = prix_unitaire;
        this.date_expiration = date_expiration;
        this.fournisseur = fournisseur;
        this.code_barre = code_barre;
        this.quantite = quantité_livrée;
        this.type_de_produits = type_de_produits;
        this.pays_origine = pays_origine;
        this.poids = poids;

    }

    //Le deuxieme constructeur

    public Produits(int code_barre, String pays_origine, float quantité_livrée, String type_de_produits) {

        this.prix_unitaire = 2;
        this.fournisseur = "coca";
        this.code_barre = code_barre;
        this.quantite = quantité_livrée;
        this.type_de_produits = type_de_produits;
        this.pays_origine = pays_origine;
        this.poids = 200;

    }

    //Le troisiem constructeur

    public Produits(int code_barre, float quantité_livrée, String type_de_produits) {

        this.prix_unitaire = 2;
        this.code_barre = code_barre;
        this.quantite = quantité_livrée;
        this.type_de_produits = "Alimentaires";
        this.poids = 200;

    }
    //constructeur aléatoire:
    public Produits() {
        Random rand = new Random();
        this.nom_produit = "Valeur aléatoire ";
        this.prix_unitaire=rand.nextInt(30);
        this.type_de_produits = "Alimentaires";
        this.poids = rand.nextFloat(200);
    }

//Getters et Setters:

    public String getNom_produit() {
        return nom_produit;
    }

    public void setNom_produit(String nom_produit) {
        this.nom_produit = nom_produit;
    }

    public String getFournisseur() {
        return fournisseur;
    }

    public void setFournisseur(String fournisseur) {
        this.fournisseur = fournisseur;
    }

    public String getType_de_produits() {
        return type_de_produits;
    }

    public void setType_de_produits(String type_de_produits) {
        this.type_de_produits = type_de_produits;
    }

    public String getPays_origine() {
        return pays_origine;
    }

    public void setPays_origine(String pays_origine) {
        this.pays_origine = pays_origine;
    }

    public float getQuantite_stocké() {
        return quantite_stocké;
    }

    public void setQuantite_stocké(float quantite_stocké) {
        this.quantite_stocké = quantite_stocké;
    }

    public float getPrix_unitaire() {
        return prix_unitaire;
    }

    public void setPrix_unitaire(float prix_unitaire) {
        this.prix_unitaire = prix_unitaire;
    }

    public float getPoids() {
        return poids;
    }

    public void setPoids(float poids) {
        this.poids = poids;
    }

    public float getQuantite() {
        return quantite;
    }

    public void setQuantite(float quantite) {
        this.quantite = quantite;
    }



    public int getDate_expiration() {
        return date_expiration;
    }

    public void setDate_expiration(int date_expiration) {
        this.date_expiration = date_expiration;
    }

    //Methode d'affichage:
    public void afficherProduits() {
        System.out.println("Le produit stocké est :" + nom_produit
                + "," + quantite_stocké + "," + prix_unitaire + ","
                + date_expiration + "," + fournisseur + "," + code_barre + "," + pays_origine+
                "," + quantite  + "," + type_de_produits + "," + poids);
    }

    //Ajout d'un produit
    private List <Produits> listeProduits;
    public void ajouterProduit(Produits produit) {
        listeProduits.add(produit);
    }


    // Méthode pour supprimer un produit
    public void supprimerProduit(Produits produit) {
        listeProduits.remove(produit);
    }


    // Méthode pour calculer le nombre total de produits dans le stock
    public int calculerNombreTotalProduits() {
        int totale= 0;
        for (Produits produit : listeProduits) {
            totale += produit.getQuantite_stocké();
        }
        return totale;
    }

    @Override
    public int getCode() {
        return 0;
    }

    @Override
    public void setCode() {

    }
}