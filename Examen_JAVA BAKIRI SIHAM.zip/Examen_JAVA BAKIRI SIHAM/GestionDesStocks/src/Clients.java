import java.util.ArrayList;
import java.util.List;
import java.util.Random;
public class Clients {

    //Les attributs de classe:
    int nombre_clients = 40;

    //  les attributs d'instances :

    public String nom_client;
    public String le_gerant;
    public String adresse;
    public String email;
    public int nb_camions;
    public String jours_de_livraison, type_de_produits, pays;
    public float quantité_livrée;
    public String moyen_de_transport;


    //Le Premier constructeur:

    public Clients(String nom_client, String le_gerant, String adresse,
                   String email, int nb_camions, String jours_de_livraison,
                   int quantité_livrée, String type_de_produits, String pays,
                   String moyen_de_transport) {


        this.nom_client = nom_client;
        this.le_gerant = le_gerant;
        this.adresse = adresse;
        this.email = email;
        this.nb_camions = nb_camions;
        this.jours_de_livraison = jours_de_livraison;
        this.quantité_livrée= quantité_livrée;
        this.type_de_produits = type_de_produits;
        this.pays = pays;
        this.moyen_de_transport = moyen_de_transport;

    }

    //Le dexieme constructeur:
    public Clients(String nom_client, String le_gerant, String adresse,
                   String email, int nb_camions, String jours_de_livraison,
                   String moyen_de_transport) {


        this.nom_client = nom_client;
        this.le_gerant = le_gerant;
        this.adresse = adresse;
        this.email = email;
        this.nb_camions = nb_camions;
        this.jours_de_livraison = jours_de_livraison;
        this.moyen_de_transport = moyen_de_transport;

    }
    //Le troisieme constructeur:
    public Clients(String nom_client, String le_gerant, String adresse,
                    int nb_camions, String jours_de_livraison,
                   int quantité_livrée, String type_de_produits, String pays,
                   String moyen_de_transport) {


        this.nom_client = nom_client;
        this.le_gerant = le_gerant;
        this.adresse = adresse;
        this.nb_camions = 3;
        this.jours_de_livraison = "Marid";
        this.quantité_livrée= quantité_livrée;
        this.type_de_produits = type_de_produits;
        this.pays = pays;
        this.moyen_de_transport = moyen_de_transport;

    }

    //Le constructeur Aléatoire:

    public Clients() {
        Random rand = new Random();

        this.nom_client = "Valeur aléatoire ";
        this.nb_camions=rand.nextInt(100);
        this.pays = "Valeur aléatoire ";
        this.quantité_livrée = rand.nextFloat(200);
    }

//Les methodes:

    //les getters et Setters:

    public int getNombre_clients() {
        return nombre_clients;
    }

    public void setNombre_clients(int nombre_clients) {
        this.nombre_clients = nombre_clients;
    }

    public String getNom_client() {
        return nom_client;
    }

    public void setNom_client(String nom_client) {
        this.nom_client = nom_client;
    }

    public String getLe_gerant() {
        return le_gerant;
    }


    public void setLe_gerant(String le_gerant) {
        this.le_gerant = le_gerant;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getNb_camions() {
        return nb_camions;
    }

    public void setNb_camions(int nb_camions) {
        this.nb_camions = nb_camions;
    }

    public String getJours_de_livraison() {
        return jours_de_livraison;
    }

    public void setJours_de_livraison(String jours_de_livraison) {
        this.jours_de_livraison = jours_de_livraison;
    }

    public String getType_de_produits() {
        return type_de_produits;
    }

    public void setType_de_produits(String type_de_produits) {
        this.type_de_produits = type_de_produits;
    }

    public String getPays() {
        return pays;
    }

    public void setPays(String pays) {
        this.pays = pays;
    }

    public float getQuantité_livrée() {
        return quantité_livrée;
    }

    public void setQuantité_livrée(float quantité_livrée) {
        this.quantité_livrée = quantité_livrée;
    }

    public String getMoyen_de_transport() {
        return moyen_de_transport;
    }

    public void setMoyen_de_transport(String moyen_de_transport) {
        this.moyen_de_transport = moyen_de_transport;
    }

    public List<String> getListeClients() {
        return listeClients;
    }

    public void setListeClients(List<String> listeClients) {
        this.listeClients = listeClients;
    }


    //Methode d'affichage des attributs:
    public void afficherClients() {
        System.out.println("Mon client est : " + this.nom_client + "," + this.le_gerant
                + "," + this.adresse + "," + this.email +
                "," + this.nb_camions + "," + this.jours_de_livraison
                + "," + this.quantité_livrée + "," + this.pays + "," + this.moyen_de_transport);
    }


    //creer une liste de clients (on va stocker les clients ici):
    List<String> listeClients = new ArrayList<>();

    // Méthode pour ajouter un client
    public void ajouterClient(Clients client) {
        listeClients.add(String.valueOf(client));
    }

    //Methode pour verifier si un client existe dans ma liste ou pas
    public String ClientExiste(String client ) {

        for (int i = 0; i < listeClients.size(); i++) {
            if (client == listeClients.get(i)) {
                System.out.println("ce nom de client est dans la liste");
                break;
            }
            else {
                System.out.println("ce nom de client n'existe pas dans la liste");
            }
        }
        return client;
    }
}

