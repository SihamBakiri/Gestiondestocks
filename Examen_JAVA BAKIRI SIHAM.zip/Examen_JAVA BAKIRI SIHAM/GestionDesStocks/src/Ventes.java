import java.util.Random;

public class Ventes {

    //Attibut de classe
    float vente_annuelles=98798006.456f;

    //Les attributs d'instance
        String nom_produit,nom_client;
        String jour_vente;
        int code_barre;
        float quantite,prix;
        boolean stock=true;
        int nb_palettes_vendues;

        //Le premier constructeur
        public Ventes (String nom_produit,String nom_client,String jour_vente, int code_barre,
                       float prix,int nb_palettes_vendues,boolean stock){


            this.nom_produit = nom_produit;
            this.nom_client = nom_client;
            this.code_barre=code_barre;
            this.jour_vente=jour_vente;
            this.nb_palettes_vendues=nb_palettes_vendues;
            this.quantite=quantite;
            this.prix=prix;
            this.stock=stock;

}
    //Le deuxieme constructeur
    public Ventes (String nom_produit, int code_barre,
                   float prix,int nb_palettes_vendues,boolean stock) {

        this.nom_produit = nom_produit;
        this.code_barre = code_barre;
        this.nb_palettes_vendues = 34;
        this.quantite = quantite;
        this.prix = prix;
        this.stock = stock;
    }
   //Le troisieme constructeur
    public Ventes (String nom_produit,boolean stock) {

        this.nom_produit = nom_produit;
        this.stock = true;
    }

    //Le constructeur aléatoire
    public Ventes() {
        Random rand = new Random();

        this.nom_produit =  "Valeur aléatoire ";
        this.nom_client =  "Valeur aléatoire ";
        this.code_barre=rand.nextInt(3099);
        this.jour_vente= "Valeur aléatoire ";
        this.quantite = rand.nextFloat(200);

    }

    //get et Set:

    public String getNom_produit() {
        return nom_produit;
    }

    public void setNom_produit(String nom_produit) {
        this.nom_produit = nom_produit;
    }

    public String getNom_client() {
        return nom_client;
    }

    public void setNom_client(String nom_client) {
        this.nom_client = nom_client;
    }

    public String getJour_vente() {
        return jour_vente;
    }

    public void setJour_vente(String jour_vente) {
        this.jour_vente = jour_vente;
    }

    public int getCode_barre() {
        return code_barre;
    }

    public void setCode_barre(int code_barre) {
        this.code_barre = code_barre;
    }

    public float getQuantite() {
        return quantite;
    }

    public void setQuantite(float quantite) {
        this.quantite = quantite;
    }

    public float getPrix() {
        return prix;
    }

    public void setPrix(float prix) {
        this.prix = prix;
    }

    public boolean isStock() {
        return stock;
    }

    public void setStock(boolean stock) {
        this.stock = stock;
    }

    public int getNb_palettes_vendues() {
        return nb_palettes_vendues;
    }

    public void setNb_palettes_vendues(int nb_palettes_vendues) {
        this.nb_palettes_vendues = nb_palettes_vendues;
    }

    //methode d'affichage:
    public void afficherVente() {
        System.out.println(" Les informations sur les ventes sont : "
                + this.nom_produit + "," +this.nom_client+","+ this.jour_vente+ "," + this.quantite +
                 "," + this.code_barre + "," + this.stock + "," + this.nb_palettes_vendues
                + "," + this.prix);
    }
}
