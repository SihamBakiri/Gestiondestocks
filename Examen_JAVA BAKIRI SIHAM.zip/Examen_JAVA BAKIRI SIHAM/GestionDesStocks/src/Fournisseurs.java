import java.util.Random;

public class Fournisseurs implements InterfaceModel{
    //Attribut de classe:
    int nombre_fournisseurs=60;

    //attributs d'instances:

    public String nom,adresse,pays,ville,produits_livree,email;
    public float quantite_livree;
    public int telephone, contact,matricule;

    //Le Premier constructeur
    public Fournisseurs(String nom, int matricule,String adresse,String ville,String pays, int contact, int telephone,String email,String produits_livree, float quantite_livree) {
        this.nom = nom;
        this.matricule = matricule;
        this.adresse = adresse;
        this.ville = ville;
        this.pays = pays;
        this.contact = contact;
        this.telephone = telephone;
        this.email = email;
        this.produits_livree = produits_livree;
        this.quantite_livree = quantite_livree;
    }
    //Le deuxieme constructeur
    public Fournisseurs(String nom, String ville,String pays, int contact, int telephone,String email,String produits_livree, float quantite_livree) {
        this.nom = nom;
        this.ville = ville;
        this.pays = "Algerie";
        this.contact = contact;
        this.telephone = telephone;
        this.email = email;
        this.produits_livree = produits_livree;
        this.quantite_livree = quantite_livree;
    }
    //Le troisieme constructeur
    public Fournisseurs(String nom) {
        this.nom = nom;

    }

    //Le constructeur aleatoire:
    public Fournisseurs() {
        Random rand = new Random();
        this.nom = "Venus";
        this.telephone = rand.nextInt(546);
    }

    //les get et set
    public String getProduits_livree() {
        return produits_livree;
    }

    public void setProduits_livree(String produits_livree) {
        this.produits_livree = produits_livree;
    }

    public float getQuantite_livree() {
        return quantite_livree;
    }

    public void setQuantite_livree(float quantite_livree) {
        this.quantite_livree = quantite_livree;
    }

    public int getTelephone() {
        return telephone;
    }

    public void setTelephone(int telephone) {
        this.telephone = telephone;
    }

    public int getContact() {
        return contact;
    }

    public void setContact(int contact) {
        this.contact = contact;
    }

    public int getMatricule() {
        return matricule;
    }

    public void setMatricule(int matricule) {
        this.matricule = matricule;
    }

    //Get et Set générer par l'interface:
    @Override
    public String getNom() {
        return null;
    }

    @Override
    public int getAdresse() {
        return 0;
    }

    @Override
    public int getEmail() {
        return 0;
    }

    @Override
    public int getVille() {
        return 0;
    }

    @Override
    public int getPays() {
        return 0;
    }

    @Override
    public void setNom(String nom) {

    }

    @Override
    public void setAdresse(String adresse) {

    }

    @Override
    public void setEmail(String email) {

    }

    @Override
    public void setVille(String ville) {

    }

    @Override
    public void setPays(String pays) {

    }

    //Affichage des infos :
    public void afficherFournisseurs() {
        System.out.println("Le fournisseur est : " + this.nom + "," + this.matricule + "," + this.adresse + "," +this.ville  +"," + this.pays+","+ this.email +
                "," + this.contact + "," + this.telephone+ "," + this.produits_livree  + "," + this.quantite_livree);
    }


}
