public interface InterfaceModel {

    //Les getters
    public String getNom();

    public int getAdresse();

    public int getEmail();

    public int getVille();

    public int getPays();

    //les setters:
    public void setNom(String nom);
    public void setAdresse(String adresse);
    public void setEmail(String email);
    public void setVille(String ville);
    public void setPays(String pays);

}
