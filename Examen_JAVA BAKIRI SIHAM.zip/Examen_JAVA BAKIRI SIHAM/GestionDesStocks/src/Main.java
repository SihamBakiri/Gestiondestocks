import java.util.Scanner;
import java.io.IOException;
import java.util.Random;
import javax.swing.*;

public class Main {

    //Les attributs de classe
    public String monApplication;
    private static Application application;


    public static void main(String[] args) {

        // Instancier l'application
        application = new Application();

        // Création de l'interface graphique
        SwingUtilities.invokeLater(() -> {
            new MainFrame(application);
        });


        // Lancement de l'application
        application.start();

        // Attente de la commande d'arrêt
        Scanner scanner = new Scanner(System.in);
        //System.out.println("Appuyez sur Entrée pour arrêter l'application.");
        scanner.nextLine();

        // Arrêt de l'application
        application.stop();
    }

    static class Application {
        private boolean running;
        public void start() {
            running = true;

            System.out.println("Voici mon Application");

            // 5 objets de classe clients
            Clients client001 = new Clients("Jack", "Siham", "rsllpoi", "poip", 3, "saedi", 300, "hygienne", "france", "camion");
            Clients client002 = new Clients("Ramirez", "Master 1", "erfg", "ffff",23,"Samedi","bateau");
            Clients client003 = new Clients("khjgh", "moi","PARIS",22,"dimanche",222,"bebe","turkie","bateau");
            Clients client004 = new Clients("s", "eer", "ezrtyi", "@khjgh", 23, "dimanche", 121, "bebe", "Turkie", "avion");
            client001.afficherClients();
            client002.afficherClients();

            //Creer un client aleatoire:
            Clients RandomClient5 = new Clients();
            RandomClient5.afficherClients();

            // 5 objets de classe Depots

            Depots depots1 = new Depots(2345, "premier", "@paris", "paris", "france", "fabrice", 23, 45, "aluminium", 234);
            Depots depots2 = new Depots("LILLE","france","Toma",123f);
            Depots depots3 = new Depots("lyon","france", "siham",9345f);
            Depots depots4 = new Depots(34565, "cinq", "@paris", "paris", "gabon", "siham", 23, 45, "aluminium", 234);
            depots1.afficherDepot();
            depots2.afficherDepot();
           //Un depot aléatoire:
            Depots Randomdepots5 = new  Depots();
            Randomdepots5.afficherDepot();


            //5 objets de classe fournisseurs:
            Fournisseurs fournisseurs1 = new Fournisseurs("kiabi", 45, "@ma", "alger", "algerie", 3876, 213, "@kiabi", "vetements", 540);
            Fournisseurs fournisseurs2 = new Fournisseurs("caprisun", 45, "@ma", "alger", "algerie", 9093, 213, "@kiabi", "jus", 540);
            Fournisseurs fournisseurs3 = new Fournisseurs("coilius","maroco","maroc",34567,9808,"@opop","linge",234f);
            Fournisseurs fournisseurs4 = new Fournisseurs("venus", 45, "@ma", "alger", "algerie", 6930, 213, "@kiabi", "cosmetique", 540);
            fournisseurs1.afficherFournisseurs();
            fournisseurs2.afficherFournisseurs();

            //un objet aléatoire:
            Fournisseurs Randomf5 = new Fournisseurs();
            Randomf5.afficherFournisseurs();

           //5 Objets de classe produits:
            Produits produit1 = new Produits("boisson", 78234, 2, 1202, "COCA", 3344556, "amerique", 88.9f, "boisson", 1);
            Produits produit2 = new Produits("shampoing", 4534, 1, 1202, "palmolive", 3344556, "amerique", 88.9f, "boisson", 1);
            Produits produit3 = new Produits(34567,"bresil",56,"cafe");
            Produits produit4 = new Produits(7899,78.9f,"tabac");
            produit1.afficherProduits();
            produit2.afficherProduits();


            Produits Randomproduit5 = new Produits();
            Randomproduit5.afficherProduits();

            //5 objets de classe Responsable
            Responsable_de_gestion gerant1 = new Responsable_de_gestion("ss", "ba", "noisy le sec", "@bakiri", 980, 2001, 3, 234f, "comptabilite", "gestion");
            Responsable_de_gestion gerant2 = new Responsable_de_gestion("siham", "ba", "noisy le sec", "@bakiri", 980, 2001, 3, 234f, "comptabilite", "gestion");
            Responsable_de_gestion gerant3 = new Responsable_de_gestion("jhjhg","kabyle","@jhjgy",2,345f,"directeur");
            Responsable_de_gestion gerant4 = new Responsable_de_gestion("TOTO","TATA","@uoui",121223,5,56578,"gerant","gere");
            System.out.println(gerant1.getAdresse());
            gerant2.afficherResponsable();
            //objet aleatoire:
            Responsable_de_gestion Randomgerant5 = new Responsable_de_gestion();
            Randomgerant5.afficherResponsable();

            //5 objets de classe Ventes
            Ventes v1=new Ventes("P",false);
            Ventes v2= new Ventes("T",23456,4.5f,8,true);
            Ventes v3= new Ventes("K","u","samedi",789,34,9,true);
            Ventes v4=new Ventes("pomme",false);
            v1.afficherVente();
            v3.getCode_barre();

            //une vente aléatoire:
            Ventes Randomv5=new Ventes();
            Randomv5.afficherVente();

        }

        public void stop() {
            running = false;
            System.out.println("Appuyez sur Entrée pour arrêter l'application.");
        }

    }
    static class MainFrame extends JFrame {
        public MainFrame(Application application) {
            setTitle("Application");
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // Ajout des composants graphiques
            JPanel panel = new JPanel();
            panel.add(new JLabel("Application en cours d'exécution"));
            add(panel);

            // Affichage de l'interface graphique
            pack();
            setVisible(true);


            // Fermeture de l'interface graphique
            dispose();
        }
    }
}
